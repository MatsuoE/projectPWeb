<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

class addMemberController extends Controller
{
    public function index(){
        return view('dashboard.data.add-member', [
            'title' => 'Add New Member',
            'user' => auth()->user()
        ]);
    }

    public function store(Request $request){
        $validatedData = $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|email:dns|unique:users',
            'password' => 'required|min:8|max:20',
            'address' => 'required|max:255',
            'number' => 'required|unique:users|max:255'
        ]);
        $validatedData['isAdmin'] = 0;
        $validatedData['password'] = bcrypt($validatedData['password']);
        User::create($validatedData);
        return redirect('/dashboard/member')->with('success', 'New member has been added');
    }
}